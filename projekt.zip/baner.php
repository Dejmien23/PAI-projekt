<section id="banner">
	<div class="inner">
		<h1>DyD</h1>
		<p><a href ="#footer">Fotografia i podróże</a></p>
	</div>

	<video autoplay loop muted playsinline src="images/banner.jpg"></video>
</section>