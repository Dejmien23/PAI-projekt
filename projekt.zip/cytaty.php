<section id="cta" class="wrapper">
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <div class="inner">
        <h2>Lewis Hine</h2>
        <p>Chociaż fotografie nie mogą kłamać, kłamcy mogą fotografować</p>
      </div>
    </div>
    <div class="carousel-item">
      <div class="inner">
        <h2>Ansel Adams</h2>
        <p>Dobre zdjęcie, to wiedzieć gdzie się ustawić</p>
      </div>
    </div>
    <div class="carousel-item">
      <div class="inner">
        <h2>Ansel Adams</h2>
        <p>Najważniejszy element aparatu znajduje się 12 cali za nim.</p>
      </div>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Poprzedni</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Następny</span>
  </a>
</div>
</section>