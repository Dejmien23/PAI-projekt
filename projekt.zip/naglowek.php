<header id="header">
	<a class="logo" href="index.php">DyD - Fotografia i podróże </a>
	
	<nav>
		<a href="#menu">Menu</a>
	</nav>
	
</header>