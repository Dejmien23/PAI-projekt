<footer id="footer">
	<div class="inner">
		<div class="content">
			<section>
				<h3>Hej! Jestem Damian!</h3>
				<p>Cieszę się, że wpadłeś. Mam nadzieję, że spodoba Ci się to, co tu znajdziesz ;)</p>
				<h3>Znajdziesz mnie na tych platformach:</h3>
				<a href="https://twitter.com/Dejmien23"><i class="icon fa-twitter">&nbsp;</i>  Twitter  </a>
				<a href="https://www.facebook.com/WOLFIE96"><i class="icon fa-facebook">&nbsp;</i>  Facebook  </a>
				<a href="https://www.instagram.com/mlody.reformowany"><i class="icon fa-instagram">&nbsp;</i>  Instagram  </a>
				<a href="https://github.com/Dejmien23?tab=repositories"><i class="icon fa-github">&nbsp;</i>  Github  </a>
				<p></p>
			</section>
		</div>
		<div class="copyright">
			<a href="#banner"> &copy; Dyd. Fotografia i podróże 2020. </a>
		</div>
	</div>
</footer>